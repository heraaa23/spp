<?php

$nama_kelas = $_POST['nama_kelas'];
$kompetensi_kejurusan = $_POST['kompetensi_kejurusan'];

include'../koneksi.php';
$sql = "INSERT INTO kelas(nama_kelas,kompetensi_kejurusan) VALUES('$nama_kelas','$kompetensi_kejurusan')";
$query = mysqli_query($koneksi, $sql);
if($query){
	header("location:?url=kelas");
}else{
	echo"<script>alert('Maaf Data Tidak Tersimpan'); window.location.assign('?url=kelas');</script>";
}